/**
 * 
 */
/**
 * 
 */
module CustomerFeedback {
	requires java.sql;
	requires java.desktop;
}